package jump2java;

public class sample0305_4 {
   public static void main(String[] args) {
	   StringBuffer sb = new StringBuffer();
	   sb.append("Hello jump to java");
	   System.out.println(sb.substring(0, 4));
   }
   
}
